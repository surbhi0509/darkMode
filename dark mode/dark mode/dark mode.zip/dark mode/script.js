document.documentElement.classList.toggle("dark-mode");
